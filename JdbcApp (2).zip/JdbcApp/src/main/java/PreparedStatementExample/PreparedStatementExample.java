package PreparedStatementExample;

public class PreparedStatementExample {

}
